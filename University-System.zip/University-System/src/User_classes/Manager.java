package User_classes;
import Enums.*;

public class Manager extends User {
    private double salary;
    private int job_experience;
    private Faculty faculty;

    public Manager(String login, String password, String id, String firstname, String lastname){
        super(login, password, id, firstname, lastname);
    }

    public String getFullname()
    {
        return firstname + ' ' + lastname;
    }
}
