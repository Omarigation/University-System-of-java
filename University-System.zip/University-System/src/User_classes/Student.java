package User_classes;
import Enums.*;
import Function.CourseType;

import java.util.List;
import java.util.Vector;

public class Student extends User{
    public Student(String login, String password, String id, String firstname, String lastname){
        super(login, password, id, firstname, lastname);
    }

    public String getFullName(){
        return this.firstname + ' ' + this.lastname;
    }

}
