package User_classes;
import Enums.*;

public class Teacher extends User{
    Position position;

    public Teacher(String login, String password, String id, String firstname, String lastname, Position pos){
        super(login, password, id, firstname, lastname);
        position = pos;
    }

    public String getFullname()
    {
        return firstname + ' ' + lastname;
    }

    public Position getPosition() {
        return position;
    }
}

