package Enums;

public enum Subject {
    Object_oriented_programming,
    Physics,
    Mathematics,
    Computer_network_basics,
    Philosophy;
}
