package Enums;

public enum Grades {
    A,
    B,
    C,
    D,
    F;
}
