package Enums;

public enum Degree {
    Bachelor,
    Master,
    Doctorate;
}
