package Enums;

public enum Faculty {
    Journalism_and_Reporting_case,
    Management_and_Control,
    Information_technology,
    Finance_Economy_Banking;
}
