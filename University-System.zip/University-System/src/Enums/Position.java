package Enums;

public enum Position {
    Professor,
    Lecturer,
    Tutor;
}
