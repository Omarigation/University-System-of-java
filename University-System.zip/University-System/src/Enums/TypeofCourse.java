package Enums;

public enum TypeofCourse {
    Lab,
    Lecture,
    Practical;
}
