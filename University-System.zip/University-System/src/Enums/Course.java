package Enums;

public enum Course {

}
