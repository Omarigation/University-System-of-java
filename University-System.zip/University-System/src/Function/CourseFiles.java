package Function;
import java.lang.*;


public class CourseFiles {
    private String title;
    private String text;


    public CourseFiles(String title1, String text1){
        this.title = title1;
        this.text = text1;
    }


    @Override
    public boolean equals(Object obj){
        if(this == obj)
            return true;
        if(obj == null)
            return false;
        if(getClass() != obj.getClass())
            return false;
        CourseFiles other = (CourseFiles) obj;
        if(text == null){
            if(other.text != null)
                return false;
        } else if (!text.equals(other.text))
            return false;

        if(title == null){
            if(other.title != null)
                return false;
        } else if (!title.equals(other.title))
            return false;
        return true;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }


}
