package Function;

import User_classes.Manager;

public class News {
    private String title;
    private String text;
    private String date;
    private Manager author;

    public News(String title,String text,String date,Manager author){
        this.text=text;
        this.title=title;
        this.date=date;
        this.author=author;
    }

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getDate() {
        return date;
    }

    public Manager getAuthor() {
        return author;
    }
}
