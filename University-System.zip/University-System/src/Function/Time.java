package Function;

public class Time {
    private int day;
    private int hour;

    public Time(int day, int hour){
        this.day = day;
        this.hour = hour;
    }

    public String getDay() {
        String str = "";
        if(day == 1)
            str = "Monday";
        else if (day == 2)
            str = "Tuesday";
        else if(day == 3)
            str = "Wednesday";
        else if(day == 4)
            str = "Thursday";
        else if(day == 5)
            str = "Friday";
        else if(day == 6)
            str = "Saturday";
        return str;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    @Override
    public String toString() {
        return getDay() + " " + getHour() +":00";
    }
}
