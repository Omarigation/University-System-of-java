package Function;

public class Mark {
    private double first;
    private double second;
    private double finalPoint;

    public Mark(double first1, double second1, double finalPoint1){
        this.first = first1;
        this.second = second1;
        this.finalPoint = finalPoint1;
    }

    public double getFirst() {
        return first;
    }

    public void setFirst(double first) {
        this.first = first;
    }

    public double getSecond() {
        return second;
    }

    public void setSecond(double second) {
        this.second = second;
    }

    public double getFinalPoint() {
        return finalPoint;
    }

    public void setFinalPoint(double finalPoint) {
        this.finalPoint = finalPoint;
    }
}
