package Function;

import java.util.Vector;

public class Course {
    String name;
    public Vector<CourseType> courseTypes;

    public Course(String name, Vector<CourseType> courseType){
        this.name = name;
        courseTypes = courseType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Vector<CourseType> getCourseTypes() {
        return courseTypes;
    }

    public void setCourseTypes(Vector<CourseType> courseTypes) {
        this.courseTypes = courseTypes;
    }
}
