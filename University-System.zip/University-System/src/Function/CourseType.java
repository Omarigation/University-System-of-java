package Function;
import Enums.*;
import User_classes.Student;
import User_classes.Teacher;

import java.util.HashMap;
import java.util.Vector;

public class CourseType {
    public TypeofCourse type;
    public Teacher teacher;
    public int room;
    public Time time;
    Vector<CourseFiles> courseFile = new Vector<>();
    HashMap<Student, Mark> students = new HashMap<>();

    public CourseType(TypeofCourse type1, Teacher teacher1, int room1, Time time1, HashMap<Student, Mark> students1) {
        this.type = type1;
        this.teacher = teacher1;
        this.room = room1;
        this.time = time1;
        this.students = students1;
    }

    public HashMap<Student, Mark> getStudents() {
        return students;
    }

    public void setStudents(HashMap<Student, Mark> students) {
        this.students = students;
    }

    public int getRoom() {
        return room;
    }

    public void setRoom(int room) {
        this.room = room;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public TypeofCourse getType() {
        if(type == TypeofCourse.Lecture)
            return TypeofCourse.Lecture;
        if(type == TypeofCourse.Lab)
            return TypeofCourse.Lab;
        return TypeofCourse.Practical;
    }

    public void setType(TypeofCourse type) {
        this.type = type;
    }

    public Vector<CourseFiles> getCourseFile() {
        return courseFile;
    }

    public void setCourseFile(Vector<CourseFiles> courseFile) {
        this.courseFile = courseFile;
    }
    public void add(CourseFiles courseFiles){
        this.courseFile.add(courseFiles);
    }


}
