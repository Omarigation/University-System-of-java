package Main;

import Enums.*;
import Enums.TypeofCourse;
import Function.Course;
import User_classes.*;
import Function.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class Main {
    public static BufferedReader console = new BufferedReader(new InputStreamReader(System.in));
    static Vector<Admin> admins = new Vector<Admin>();
    static Vector<Student> students = new Vector<Student>();
    static Vector<Teacher> teachers = new Vector<Teacher>();
    static Vector<Manager> managers = new Vector<Manager>();
    static Vector<Course> courses = new Vector<Course>();
    static Vector<News> news = new Vector<News>();


    public static void main(String[] args) throws IOException {
        Startdefault();
        start();
    }


    public static void Startdefault(){
        Admin a1 = new Admin("admin", "admin", "Akhmet", "Baitursynov");
        Admin a2 = new Admin("admin1", "admin1", "Abay", "Kunanbaev");
        admins.add(a1);
        admins.add(a2);

        Student s1 = new Student("student", "innabat1234", "t101", "Innabat", "Zhenissova");
        Student s2 = new Student("student1", "isaak1234", "s101", "Isaak", "Einstein");
        students.add(s1);
        students.add(s2);

        Teacher t1 = new Teacher("teacher", "diana1234", "t100", "Diana", "Muratbek", Position.Professor);
        Teacher t2 = new Teacher("teacher1", "teacher1", "t101", "Uzbek", "Uzbekovich", Position.Lecturer);
        teachers.add(t1);
        teachers.add(t2);


        Manager m1 = new Manager("manager", "aida1234", "m100", "Aida", "Abdullayeva");
        Manager m2 = new Manager("manager1", "ainur1234", "m101", "Ainur", "Kabylzhan");
        managers.add(m1);
        managers.add(m2);

        Vector<CourseType> courseTypes = new Vector<CourseType>();

        Mark mark1 = new Mark(30,20,40); //A
        Mark mark2 = new Mark(10,30,10 );
        Mark mark3 = new Mark(15,15,30);
        Mark mark4 = new Mark(6,7,0 );


        HashMap<Student, Mark> ma1 = new HashMap<Student, Mark>();
        ma1.put(s1, mark1);
        ma1.put(s2, mark2);

        HashMap<Student, Mark> ma2 = new HashMap<Student, Mark>();
        ma2.put(s1, mark3);
        ma2.put(s2, mark4);


        Time time = new Time(6, 9);
        CourseType SIS1 = new CourseType(TypeofCourse.Practical, t1, 800,time, ma1);

        Time time1 = new Time(4, 11);
        CourseType SIS2 = new CourseType(TypeofCourse.Lecture, t2, 801,time1, ma2);

        courseTypes.add(SIS1);
        courseTypes.add(SIS2);

        Course Math = new Course("Math", courseTypes);
        Course OOP = new Course("OOP", courseTypes);
        courses.add(Math);
        courses.add(OOP);


        News news1 = new News("International Cybersecurity conference", "Conference will start at 20-00 (800 room)", "12/12/2023", m1);
        News news2 = new News("IT Coorparation", "Invite all IITU students at 16:00", "25/11/2023", m2);
        news.add(news1);
        news.add(news2);

    }

    public static void start()throws IOException {
        System.out.println("UNIVERSITY SYSTEM");
        System.out.println("Enter your login and password");
        System.out.print("login: ");
        String login = console.readLine();
        System.out.print("password: ");
        String password = console.readLine();

        //registration
        boolean ok = false;
            if(!ok){
                for (int i = 0; i < admins.size(); i++) {
                    if(admins.get(i).getLogin().equals(login) && admins.get(i).getPassword().equals(password)){
                        startAdmin(admins.get(i));
                        ok = true;
                        break;
                    }
                }
            }
            if(!ok){
            for (int i = 0; i < students.size(); i++) {
                if(students.get(i).getLogin().equals(login) && students.get(i).getPassword().equals(password)){
                    startStudent(students.get(i));
                    ok = true;
                    break;
                }
            }
            if(!ok){
                for (int i = 0;i < teachers.size(); i++) {
                    if(teachers.get(i).getLogin().equals(login) && teachers.get(i).getPassword().equals(password)){
                        startTeacher(teachers.get(i));
                        ok = true;
                        break;
                    }
                }
            }
            if(!ok){
                for (int i = 0; i < managers.size(); i++) {
                    if(managers.get(i).getLogin().equals(login) && managers.get(i).getPassword().equals(password)){
                        startManager(managers.get(i));
                    }
                }
            }
            if(!ok){
                System.out.println("You are not registered");
                start();
            }

        }
    }

    public static void startAdmin(Admin admin) throws IOException {
        System.out.println("Welcome Admin, " + admin.getFullname());
        System.out.println("Choose your option");
        System.out.println("1) View All Students");
        System.out.println("2) Add Student");
        System.out.println("3) Delete Student");
        System.out.println("4) View All Teachers");
        System.out.println("5) Add Teacher");
        System.out.println("6) Delete Teacher");
        System.out.println("7) View All Managers");
        System.out.println("8) Add Manager");
        System.out.println("9) Delete Manager");
        System.out.println("10) Exit");

        int choice = Integer.parseInt(console.readLine());
        switch (choice){
            case 1:viewAllStudents(admin); startAdmin(admin);
            case 2: addStudent(admin); startAdmin(admin);
            case 3: deleteStudent(admin); startAdmin(admin);
            case 4: viewAllTeachers(admin); startAdmin(admin);
            case 5: addTeacher(admin); startAdmin(admin);
            case 6: deleteTeacher(admin); startAdmin(admin);
            case 7: viewAllManagers(admin); startAdmin(admin);
            case 8: addManager(admin); startAdmin(admin);
            case 9: deleteManager(admin); startAdmin(admin);
            case 10: start();
            default:{
                System.out.println("Invalid option");
                startAdmin(admin);
            }
        }
    }


    public static void viewAllStudents(Admin admin)throws IOException{
        if(students.isEmpty()){
            System.out.println("Don't have any students");
            startAdmin(admin);
        }
        for (int i = 0; i < students.size(); i++) {
            System.out.println((i + 1) + ") " + students.get(i).getFullName());
        }
        System.out.println("************************************");
        startAdmin(admin);
    }
    public static void addStudent(Admin admin) throws IOException{
        System.out.println("Enter login, password, id, first name, last name !");

        String newLogin = console.readLine(), newPassword = console.readLine(), newID = console.readLine(), newFirstname = console.readLine(), newLastname = console.readLine() ;
        Student s1 = new Student(newLogin, newPassword, newID, newFirstname, newLastname);
        students.add(s1);
        System.out.println("Successfully Student added\n");
        startAdmin(admin);
    }

    public static void deleteStudent(Admin admin) throws IOException{
        if(students.isEmpty()){
            System.out.println("Sorry, but there are no students yet\n");
            startAdmin(admin);
        }

        System.out.println("Which student do you want to delete");

        for (int i = 0; i < students.size(); i++) {
            System.out.println((i + 1) + ") " + students.get(i).getFullName());
        }

        int index = Integer.parseInt(console.readLine());
        if(index > students.size()){
            System.out.println("Please, Enter a valid data");
            deleteStudent(admin);
        }
        students.remove(index - 1);
        System.out.println("Successfully " + students.get(index - 1).getFullName() + " deleted\n");
    }

    public static void viewAllTeachers(Admin admin) throws IOException{
        if(teachers.isEmpty()){
            System.out.println("Don't have any teachers");
            startAdmin(admin);
        }
        for (int i = 0; i < teachers.size(); i++) {
            System.out.println((i + 1) + ") " + teachers.get(i).getFullname());
        }
        System.out.println("************************************");
        startAdmin(admin);
    }

    public static void addTeacher(Admin admin) throws IOException{
        System.out.println("Enter login, password, id, full name !");

        String newLogin = console.readLine(), newPassword = console.readLine(), newFirstname = console.readLine(), newLastname = console.readLine(), newID = console.readLine();

        System.out.println("1) Lecturer");
        System.out.println("2) Professor");
        System.out.println("3) Tutor");
        int choice = Integer.parseInt(console.readLine());
        if(choice == 1)
            teachers.add(new Teacher(newLogin, newPassword, newID, newFirstname, newLastname, Position.Lecturer));
        else if (choice == 2)
            teachers.add(new Teacher(newLogin, newPassword, newID, newFirstname, newLastname, Position.Professor));
        else if(choice == 3)
            teachers.add(new Teacher(newLogin, newPassword, newID, newFirstname,newLastname, Position.Tutor));

        System.out.println("Successfully Teacher added\n");
        startAdmin(admin);
    }

    public static void deleteTeacher(Admin admin) throws  IOException{
        if(teachers.isEmpty()){
            System.out.println("Sorry, but there are no teachers yet\n");
            startAdmin(admin);
        }
        System.out.println("Which teacher do you want to delete");
        for (int i = 0; i < teachers.size(); i++) {
            System.out.println(i + 1 + ")" + teachers.get(i).getFullname());
        }

        int index = Integer.parseInt(console.readLine());
        if(index > teachers.size()){
            System.out.println("Please, Enter a valid data");
            deleteTeacher(admin);
        }
        teachers.remove(index - 1);
        System.out.println("Successfully " + teachers.get(index - 1).getFullname() + " deleted");
    }

    public static void viewAllManagers(Admin admin) throws IOException{
        if(managers.isEmpty()){
            System.out.println("Don't have any managers");
            startAdmin(admin);
        }
        for (int i = 0; i < managers.size(); i++) {
            System.out.println((i + 1) + ") " + managers.get(i).getFullname());
        }
        System.out.println("************************************");
        startAdmin(admin);
    }
    public static void addManager(Admin admin) throws IOException{
        System.out.println("Enter login, password, id, full name !");

        String newLogin = console.readLine(), newPassword = console.readLine(), newFirstname = console.readLine(), newLastname = console.readLine(), newID = console.readLine();

        managers.add(new Manager(newLogin, newPassword, newID, newFirstname,newLastname));
        System.out.println("Successfully added\n");
        startAdmin(admin);
    }

    public static void deleteManager(Admin admin)throws IOException{
        if(managers.isEmpty()){
            System.out.println("Sorry, bu there are no managers yes");
            startAdmin(admin);
        }
        System.out.println("Which manager do you want to delete");
        for (int i = 0; i < managers.size(); i++) {
            System.out.println(i + 1 + ")" + managers.get(i).getFullname());
        }

        int index = Integer.parseInt(console.readLine());
        if(index > managers.size()){
            System.out.println("Please, Enter a valid data");
            deleteManager(admin);
        }
        managers.remove(index - 1);
        System.out.println("Successfully " + managers.get(index - 1).getFullname() + " deleted");
        startAdmin(admin);
    }


    public static void startStudent(Student student) throws IOException{
        System.out.println("Welcome Student, " + student.getFullName());
        System.out.println("Please, choose one of the options:");
        System.out.println("1) News");
        System.out.println("2) Schedule");
        System.out.println("3) Marks");
        System.out.println("4) Teachers");
        System.out.println("5) Exit");
        int choice = Integer.parseInt(console.readLine());
        switch (choice){
            case 1: viewNews(student);
            case 2: viewSchedule(student);
            case 3: viewMarks(student);
            case 4: teachersOperations(student);
            case 5: start();
            default:
                System.out.println("Invalid option");
                startStudent(student);
        }
    }


    public static void viewNews(Student student) throws IOException{
        for (int i = 0; i < news.size(); i++) {
            System.out.println(news.get(i).getTitle());
            System.out.println(news.get(i).getText());
            System.out.println("Author: " + news.get(i).getAuthor().getFullname());
            System.out.println("Data: " + news.get(i).getDate());
            System.out.println();
        }
        System.out.println("************************************");
        startStudent(student);
    }

    public static void viewSchedule(Student student) throws IOException{
        for (int i = 0; i < courses.size(); i++) {
            Course course = courses.get(i);
            Vector<CourseType> v = course.getCourseTypes();
            for (int j = 0; j < v.size(); j++) {
                CourseType c = v.get(j);
                Time time = c.getTime();
                HashMap<Student, Mark> h = c.getStudents();
                if(h.containsKey(student)){
                    System.out.println(time.getDay() + " " + time.getHour() + ":00 " + course.getName() +
                            " " + c.getType() + " " + c.getRoom() + " room");
                }
            }
        }
        System.out.println("************************************");
        startStudent(student);
    }

    public static void viewMarks(Student student) throws  IOException{
        for (int i = 0; i < courses.size(); i++) {
            Course course = courses.get(i);
            Vector<CourseType> v = course.getCourseTypes();
            for (int j = 0; j < v.size(); j++) {
                CourseType c = v.get(j);
                HashMap<Student, Mark> h = c.getStudents();
                if(h.containsKey(student)){
                    System.out.println(course.getName() + " /" + c.getType() + "\nRK1 " + h.get(student).getFirst() +
                            "\nRk2 " + h.get(student).getSecond() + "\nSession " + h.get(student).getFinalPoint());
                    System.out.println();
                }
            }
        }
        System.out.println("************************************");
        startStudent(student);
    }

    public static void teachersOperations(Student student) throws  IOException{
        System.out.println("Please, choose one of the options below");
        System.out.println("1) See Teachers");
        System.out.println("2) See Teacher's schedule");
        System.out.println("3) See Teacher's Course Files");
        int choice = Integer.parseInt(console.readLine());
        switch (choice){
            case 1: viewTeachers(student);
            case 2 :{
                System.out.println("************************************");
                int a = 0;
                for (int i = 0; i < courses.size(); i++) {
                    Course c = courses.get(i);
                    Vector<CourseType> v = c.getCourseTypes();
                    for (int j = 0; j < v.size(); j++) {
                        CourseType ct = v.get(i);
                        HashMap<Student, Mark> h = ct.getStudents();
                        if(h.containsKey(student)){

                            System.out.println(a + 1 + ")" + ct.getTeacher().getFullname() + " " + ct.getTeacher().getPosition());
                            a++;
                        }
                    }
                }
                int choice1 = Integer.parseInt(console.readLine());
                a = 0;
                for (int i = 0; i < courses.size(); i++) {
                    Course c = courses.get(i);
                    Vector<CourseType> v = c.getCourseTypes();
                    for (int j = 0; j < v.size(); j++) {
                        CourseType ct = v.get(i);
                        HashMap<Student, Mark> h = ct.getStudents();
                        if(h.containsKey(student)){
                            System.out.println(ct.getTeacher().getFullname());
                            a++;
                            if(a == choice1){
                                Teacher t = ct.getTeacher();
                                for (int k = 0; k < courses.get(j).getCourseTypes().size(); k++) {
                                    CourseType ct1 = courses.get(j).getCourseTypes().get(k);
                                    if(ct1.getTeacher() == t){
                                        System.out.println(courses.get(k).getName() + " /" +ct1.getTime().getDay() + ":" +
                                                ct1.getTime().getHour() + ":00 /" + ct1.getRoom() + " room" );
                                    }
                                }
                            }
                        }
                    }
                }
                System.out.println("************************************");
                startStudent(student);
            }
            case 3:{
                System.out.println("************************************");
                int a = 0;
                for (int i = 0; i < courses.size(); i++) {
                    Course course = courses.get(i);
                    Vector<CourseType> v = course.getCourseTypes();
                    for(int j=0;j<v.size();j++) {
                        CourseType c = v.get(j);
                        HashMap<Student, Mark> h = c.getStudents();
                        if (h.containsKey(student)) {
                            System.out.println(a + 1  +  ") " + c.getTeacher().getFullname() + " " + c.getTeacher().getPosition());
                            a++;
                        }
                    }
                }
                int choice1 = Integer.parseInt(console.readLine());
                a = 0;
                for(int i=0;i<courses.size();i++) {
                    Course course = courses.get(i);
                    Vector<CourseType> v = course.getCourseTypes();
                    for (int j = 0; j < v.size(); j++) {
                        CourseType c = v.get(j);
                        HashMap<Student, Mark> h = c.getStudents();
                        if (h.containsKey(student)) {
                            System.out.println(c.getTeacher().getFullname());
                            a++;
                            if(a == choice1){
                                for (int k = 0; k < courses.size(); k++) {
                                    for (int l = 0; l < courses.get(k).getCourseTypes().size(); l++) {
                                        CourseType ct = courses.get(k).getCourseTypes().get(l);
                                        for (int m = 0; m < ct.getCourseFile().size(); m++) {
                                            System.out.println("Name: " + courses.get(k).getName());
                                            System.out.println("Title: " + ct.getCourseFile().get(m).getTitle());
                                            System.out.println("/*" + ct.getCourseFile().get(m).getText() + "*/");

                                        }
                                    }

                                }
                            }
                        }
                    }
                }
                System.out.println("************************************");
                startStudent(student);
            }

        }

    }

    public static void viewTeachers(Student student) throws IOException{
        for (int i = 0; i < courses.size(); i++) {
            Course course = courses.get(i);
            Vector<CourseType> v = course.getCourseTypes();
            for (int j = 0; j < v.size(); j++) {
                CourseType c = v.get(j);
                HashMap<Student, Mark> h = c.getStudents();
                if(h.containsKey(student)){
                    System.out.println(c.getTeacher().getFullname() + " " + c.getTeacher().getPosition());
                }
            }
        }
        System.out.println("************************************");
        startStudent(student);
    }

    public static void startTeacher(Teacher teacher) throws IOException{
        System.out.println("Welcome Teacher, " + teacher.getFullname());
        System.out.println("Please, choose what do you want to do");
        System.out.println("1) News");
        System.out.println("2) Schedule");
        System.out.println("3) Option with courses");
        System.out.println("4) Exit");
        int choice = Integer.parseInt(console.readLine());
        switch (choice){
            case 1: viewNews(teacher);
            case 2: viewSchedule(teacher);
            case 3: optionsWithCourse(teacher);
            case 4: start();
            default: {
                System.out.println("Invalid option");
                startTeacher(teacher);
            }
        }
    }

    public static void viewNews(Teacher teacher)throws IOException{
        for (int i = 0; i < news.size(); i++) {
            System.out.println(news.get(i).getTitle());
            System.out.println(news.get(i).getText());
            System.out.println("Author: " + news.get(i).getAuthor().getFullname());
            System.out.println("Data: " + news.get(i).getDate());
        }
        System.out.println("************************************");
        startTeacher(teacher);
    }
    public static void viewSchedule(Teacher teacher) throws IOException{
        for (int i = 0; i < courses.size(); i++) {
            for (int j = 0; j < courses.get(i).getCourseTypes().size(); j++) {
                CourseType ct = courses.get(i).getCourseTypes().get(j);
                if(ct.getTeacher() == teacher){
                    System.out.println(courses.get(j).getName() + " /" + ct.getTime() + " /" + ct.getRoom() + " room");
                }
            }
        }
        System.out.println("************************************");
        startTeacher(teacher);
    }
    public static void optionsWithCourse(Teacher teacher) throws  IOException{
        System.out.println("Choose Course");
        Vector<Course> c = new Vector<Course>();
        for (int i = 0; i < courses.size(); i++) {
            Course course = courses.get(i);
            Vector<CourseType> v = course.getCourseTypes();
            for (int j = 0; j < v.size(); j++) {
                if(v.get(j).getTeacher() == teacher){
                    c.add(course);
                    System.out.println(c.size() + ") " + course.getName());
                }
            }
        }
        int choice = Integer.parseInt(console.readLine());
        Course course1 = c.get(choice - 1);
        System.out.println("What do you want to do with this course ?");
        System.out.println("1) See info about students (full names, marks)");
        System.out.println("2) Manage course files");
        System.out.println("3) Choose student and put marks");
        System.out.println("4) Back");
        System.out.println("5) Exit to home");
        int choice1 = Integer.parseInt(console.readLine());
        switch (choice1){
            case 1: seeinfoStudentofCourse(teacher, course1);
            case 2: ManageCourseFiles(teacher, course1);
            case 3: putMarks(teacher, course1);
            case 4: optionsWithCourse(teacher);
            case 5: startTeacher(teacher);
            default:
                System.out.println("Invalid option");
                optionsWithCourse(teacher);
        }


    }
    public static void seeinfoStudentofCourse(Teacher teacher, Course course) throws  IOException{
        for (int i = 0; i < courses.size(); i++) {
            Course course2 = courses.get(i);
            Vector<CourseType> v = course2.getCourseTypes();
            for(int j=0;j <v.size();j++){
                if(v.get(j).getTeacher()==teacher && course2 == course){
                    for(int k =0;k<students.size();k++){
                        Student student = students.get(k);
                        if(v.get(j).getStudents().containsKey(student)){
                            System.out.println(student.getFullName() + ": " + v.get(j).getStudents().get(student).getFirst() +
                                    " " + v.get(j).getStudents().get(student).getSecond() + " "
                                    + v.get(j).getStudents().get(student).getFinalPoint() );
                        }
                    }
                }
            }
        }
        System.out.println("************************************");
        optionsWithCourse(teacher);

    }
    public static void ManageCourseFiles(Teacher teacher, Course course) throws IOException{
        System.out.println("Choose one of this you will do");
        System.out.println("1) See course files");
        System.out.println("2) Add course files");
        System.out.println("3) Remove course files");
        System.out.println("4) Back");
        int choice = Integer.parseInt(console.readLine());

        switch (choice){
            case 1:{
                for (int i = 0; i < courses.size(); i++) {
                    Course course1 = courses.get(i);
                    Vector<CourseType> v = course1.getCourseTypes();
                    for (int j = 0; j < v.size(); j++) {
                     if(v.get(j).getCourseFile().isEmpty()){
                         System.out.println("Sorry, but there are no courses files yet");
                         ManageCourseFiles(teacher, course);
                         break;
                     }
                        for (int k = 0; k < v.get(j).getCourseFile().size(); k++) {
                            System.out.println("Title: " + v.get(j).getCourseFile().get(k).getTitle());
                            System.out.println("/* " + v.get(j).getCourseFile().get(k).getText() + " */");
                        }
                    }
                }
                System.out.println("************************************");
                optionsWithCourse(teacher);
            }
            case 2: {
                System.out.println("Write Course file title and text (for add)");
                String s = console.readLine();
                String x = console.readLine();
                CourseFiles cf = new CourseFiles(s , x);
                for (int i = 0; i < courses.size(); i++) {
                    Course course1 = courses.get(i);
                    Vector<CourseType> v = course1.getCourseTypes();
                    for (int j = 0; j < v.size(); j++) {
                        if(v.get(j).getTeacher() == teacher){
                            Vector<CourseFiles> c = v.get(j).getCourseFile();
                            v.get(j).add(cf);
                            c.add(cf);
                            v.get(j).setCourseFile(c);
                            System.out.println("Successfully Courses files added");
                            ManageCourseFiles(teacher, course);
                        }
                    }
                }
                ManageCourseFiles(teacher, course);
            }
            case 3:{
                System.out.println("Please, choose which one you want to delete");
                for (int i = 0; i < courses.size(); i++) {
                    Course course2 = courses.get(i);
                    Vector<CourseType> v = course2.getCourseTypes();
                    for (int j = 0; j < v.size(); j++) {
                        if(v.get(j).getCourseFile().isEmpty()){
                            System.out.println("Sorry, but there are no Course files yet");
                            ManageCourseFiles(teacher, course);
                        }
                        for (int k = 0; k < v.get(j).getCourseFile().size(); k++) {
                            System.out.println((k + 1) +  ") " + v.get(j).getCourseFile().get(k).getTitle());
                            System.out.println( v.get(j).getCourseFile().get(k).getText());
                        }
                    }
                }
                int choice1 = Integer.parseInt(console.readLine());
                for (int i = 0; i < courses.size(); i++) {
                    Course course1 = courses.get(i);
                    Vector<CourseType> v = course1.getCourseTypes();
                    for (int j = 0; j < v.size(); j++) {
                        if(v.get(j).getTeacher() == teacher){
                            Vector<CourseFiles> c = v.get(j).getCourseFile();
                            c.remove(choice1 - 1);
                            v.get(j).setCourseFile(c);
                        }
                    }
                }
                System.out.println("************************************");
                ManageCourseFiles(teacher, course);
                startTeacher(teacher);
            }
            case 4:optionsWithCourse(teacher);
            default:{
                System.out.println("invalid option");
                ManageCourseFiles(teacher, course);
            }
        }
    }
    public static void putMarks(Teacher teacher, Course course)throws  IOException{
        System.out.println("Please, choose a student");
        for (int i = 0; i < courses.size(); i++) {
            for (int j = 0; j < courses.get(i).getCourseTypes().size(); j++) {
                CourseType ct = courses.get(i).courseTypes.get(j);
                HashMap<Student, Mark> h = ct.getStudents();
                int a = 0;
                if(ct.getTeacher() == teacher && courses.get(i) == course) {
                    for (Map.Entry<Student, Mark> entry : h.entrySet()) {
                        a++;
                        System.out.println(a + ") " + entry.getKey().getFullName());
                    }
                }
            }
        }
        int choice = Integer.parseInt(console.readLine());
        for (int i = 0; i < courses.size(); i++) {
            for (int j = 0; j < courses.get(i).courseTypes.size(); j++) {
                CourseType ct = courses.get(i).courseTypes.get(j);
                HashMap<Student, Mark> h = ct.getStudents();
                int a = 0;
                if(ct.getTeacher() == teacher && courses.get(i) == course){
                    for (Map.Entry<Student, Mark> entry: h.entrySet()) {
                        a++;
                        if(a == choice){
                            System.out.println(entry.getKey().getFullName() + " " + entry.getValue().getFirst() +
                                    " " + entry.getValue().getSecond() + " " + entry.getValue().getFinalPoint());
                            System.out.println("Please, write your pints for the each of the attestations line by line");
                            double a1 = Double.parseDouble(console.readLine());
                            double a2 = Double.parseDouble(console.readLine());
                            double a3 = Double.parseDouble(console.readLine());
                            entry.getValue().setFirst(a1);
                            entry.getValue().setSecond(a2);
                            entry.getValue().setFinalPoint(a3);
                        }
                    }
                }
            }
        }
        System.out.println("************************************");
        startTeacher(teacher);
    }
    public static void startManager(Manager manager) throws IOException{
        System.out.println("Welcome Manager, " + manager.getFullname());
        System.out.println("Please, choose what do you want to do");
        System.out.println("1) View News");
        System.out.println("2) Add News");
        System.out.println("3) Delete New");
        System.out.println("4) View Courses");
        System.out.println("5) Add Courses");
        System.out.println("6) Delete Course");
        System.out.println("7) Exit");

        int choice = Integer.parseInt(console.readLine());
        switch (choice){
            case 1: allNews(manager); startManager(manager);
            case 2: addNews(manager); startManager(manager);
            case 3: deleteNews(manager); startManager(manager);
            case 4: allCourses(manager); startManager(manager);
            case 5: addCourses(manager); startManager(manager);
            case 6: deleteCourses(manager); startManager(manager);
            case 7: start();
            default:
                startManager(manager);
        }

    }
    public static void allNews(Manager manager) throws IOException{
        if(news.isEmpty()){
            System.out.println("Sorry, but there are no News yes");
            startManager(manager);
        }
        for (int i = 0; i < news.size(); i++) {
            System.out.println((i + 1) + ") " + news.get(i).getTitle());
        }
        startManager(manager);

    }
    public static void addNews(Manager manager)throws IOException{
        System.out.println("Please, Enter title, text, data for news!");
        String newtitle = console.readLine();
        String newtext = console.readLine();
        System.out.println("Enter data looks like this format\nyears/month/day hour/minutes/second");
        String newdata = console.readLine();

        news.add(new News(newtitle, newtext, newdata, manager));
        System.out.println("Successfully new News added\n");
        startManager(manager);
    }
    public static void deleteNews(Manager manager) throws IOException{
        if(news.isEmpty()){
            System.out.println("Sorry, but there are no news yet");
            startManager(manager);
        }
        System.out.println("Which news do you want tot delete(of title) ?");
        for (int i = 0; i < news.size(); i++) {
            System.out.println((i + 1) + ") " + news.get(i).getTitle());
        }
        int choice = Integer.parseInt(console.readLine());
        if(choice > news.size()){
            System.out.println("invalid data");
            deleteNews(manager);
        }
        System.out.println("Successfully " + news.get(choice - 1).getTitle() + " of news deleted");
        news.remove(choice - 1);
        startManager(manager);
    }
    public static void allCourses(Manager manager)throws IOException{
        if(courses.isEmpty()){
            System.out.println("Sorry, but there are no Courses yet");
            startManager(manager);
        }
        for (int i = 0; i < courses.size(); i++) {
            System.out.println((i + 1) + ") " + courses.get(i).getName());
        }
        startManager(manager);
    }
    public static void addCourses(Manager manager) throws IOException{
        Vector<CourseType> v = new Vector<CourseType>();
        System.out.println("Please, Enter name of course");
        String name = console.readLine();
        courses.add(new Course(name, v));
    }
    public static void deleteCourses(Manager manager)throws IOException{
        if(courses.isEmpty()){
            System.out.println("Sorry, but there are no courses yet");
            startManager(manager);
        }
        System.out.println("Which Course do you want to delete");
        for (int i = 0; i < courses.size(); i++) {
            System.out.println((i + 1) + ") " + courses.get(i).getName());
        }
        int choice = Integer.parseInt(console.readLine());
        if(choice > courses.size()){
            System.out.println("Invalid data");
            deleteCourses(manager);
        }
        System.out.println("Successfully " + courses.get(choice - 1).getName() + " course deleted");
        courses.remove(choice - 1);
        startManager(manager);
    }

}
